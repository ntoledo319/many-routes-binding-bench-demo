extends SceneTree
var failures := 0
func _initialize():
	run.call_deferred()
func check(condition: bool, text: String):
	if condition:
		print("PASS ", text)
	else:
		failures += 1
		push_error("FAIL " + text)
func key(code: int, pressed: bool = true):
	var event := InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = pressed
	Input.parse_input_event(event)
	Input.flush_buffered_events()
func run():
	var scene = load("res://main.tscn").instantiate()
	root.add_child(scene)
	await process_frame
	await process_frame
	check(scene.binding_buttons.size() == 2, "two real binding controls")
	scene.binding_buttons[0].pressed.emit()
	key(KEY_Q)
	key(KEY_Q, false)
	check(scene.keys[0] == KEY_Q and scene.waiting == -1, "free sample remaps through engine input")
	scene.binding_buttons[1].pressed.emit()
	key(KEY_Q)
	key(KEY_Q, false)
	check(scene.keys[1] == KEY_D and "already controls" in scene.message.text, "duplicate key rejected visibly")
	key(KEY_ESCAPE)
	key(KEY_ESCAPE, false)
	check(scene.waiting == -1 and scene.keys[1] == KEY_D, "Escape cancels capture")
	var old_position: float = scene.position_x
	key(KEY_D)
	await create_timer(0.1).timeout
	key(KEY_D, false)
	check(scene.position_x > old_position, "real action moves demo marker")
	scene.reset_defaults()
	check(scene.keys == [KEY_A, KEY_D], "reset restores both keys")
	scene.controllers = false
	scene.apply_bindings()
	check(InputMap.action_get_events("free_left").size() == 1, "controller toggle removes pad events")
	scene.queue_free()
	await process_frame
	print("RESULT ", 7-failures, "/7 free sample checks passed")
	quit(1 if failures else 0)
