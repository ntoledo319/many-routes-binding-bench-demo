# Binding Bench — free input playground

Open this folder's project.godot in Godot 4.5.1 and run it. Use A/D or a standard controller's left stick to move the dot. Click a keyboard binding and press a new key. Duplicate keys are rejected; Escape cancels; Reset restores keyboard defaults. Controller enable and dead-zone controls operate on the engine InputMap.

This standalone example is MIT licensed. It has no save/load, full-kit source dependency, network API, purchase flow or analytics. Reloading resets state. Its browser export is intended for desktop keyboards; phones can view the page but are not an equivalent input test. No physical controller has been tested in this release.

To export Web, install the official 4.5.1 export templates, import the project, then export the Web preset to a separate directory. The preset uses the single-threaded template. Serve over HTTP(S); Godot Web exports are not file:// applications. Include the engine's licence: https://godotengine.org/license/ .
