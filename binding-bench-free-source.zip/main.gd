extends Control
## Free, in-memory example. No persistence or paid addon source is included.
var keys := [KEY_A, KEY_D]
var binding_buttons: Array[Button] = []
var waiting := -1
var seconds := 0.0
var position_x := 0.5
var deadzone := 0.2
var controllers := true
var message: Label
var zone_label: Label
var arena: Control
var marker: ColorRect
var signal_label: Label
var controller_label: Label

func _ready() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 32)
	add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 14)
	margin.add_child(column)
	column.add_child(label("BINDING BENCH  /  FREE INPUT PLAYGROUND", 16))
	column.add_child(label("Two keys. One moving dot.", 36))
	column.add_child(label("Use A / D or a controller’s left stick. Change either physical key below.", 20))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	column.add_child(row)
	for index in range(2):
		var button := Button.new()
		button.custom_minimum_size = Vector2(270, 56)
		button.add_theme_font_size_override("font_size", 20)
		button.pressed.connect(begin_capture.bind(index))
		row.add_child(button)
		binding_buttons.append(button)
	var reset := Button.new()
	reset.text = "Reset"
	reset.custom_minimum_size = Vector2(120, 56)
	reset.pressed.connect(reset_defaults)
	row.add_child(reset)
	var options := HBoxContainer.new()
	options.add_theme_constant_override("separation", 20)
	column.add_child(options)
	var enabled := CheckButton.new()
	enabled.text = "Controller enabled"
	enabled.button_pressed = true
	enabled.add_theme_font_size_override("font_size", 18)
	enabled.toggled.connect(func(value: bool): controllers = value; apply_bindings())
	options.add_child(enabled)
	zone_label = label("Dead zone: 20%", 18)
	zone_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	zone_label.custom_minimum_size.x = 155
	options.add_child(zone_label)
	var slider := HSlider.new()
	slider.min_value = 0.05
	slider.max_value = 0.95
	slider.step = 0.05
	slider.value = 0.2
	slider.custom_minimum_size.x = 230
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.value_changed.connect(func(value: float): deadzone = value; zone_label.text = "Dead zone: %d%%" % roundi(value * 100); apply_bindings())
	options.add_child(slider)
	message = label("Click a binding to listen. Escape cancels. Reloading this free demo resets it.", 18)
	column.add_child(message)
	arena = Panel.new()
	arena.custom_minimum_size.y = 150
	column.add_child(arena)
	marker = ColorRect.new()
	marker.color = Color("8de0ba")
	marker.size = Vector2(22, 22)
	arena.add_child(marker)
	signal_label = label("", 16)
	column.add_child(signal_label)
	controller_label = label("", 16)
	column.add_child(controller_label)
	column.add_child(label("This free example changes two keyboard bindings in memory.\nThe complete source kit adds controller remapping, saved settings and recovery tests.", 17))
	apply_bindings()

func label(text: String, font_size: int) -> Label:
	var node := Label.new()
	node.text = text
	node.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	node.add_theme_font_size_override("font_size", font_size)
	return node

func apply_bindings() -> void:
	for index in range(2):
		var action := "free_left" if index == 0 else "free_right"
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		Input.action_release(action)
		InputMap.action_erase_events(action)
		InputMap.action_set_deadzone(action, deadzone)
		var event := InputEventKey.new()
		event.physical_keycode = keys[index]
		InputMap.action_add_event(action, event)
		if controllers:
			var axis := InputEventJoypadMotion.new()
			axis.device = -1
			axis.axis = 0
			axis.axis_value = -1.0 if index == 0 else 1.0
			InputMap.action_add_event(action, axis)
		binding_buttons[index].text = ("Move left: " if index == 0 else "Move right: ") + OS.get_keycode_string(keys[index])

func begin_capture(index: int) -> void:
	waiting = index
	seconds = 12.0
	message.text = "Press a physical key without modifiers. Escape cancels; capture expires in 12 seconds."

func reset_defaults() -> void:
	waiting = -1
	keys = [KEY_A, KEY_D]
	apply_bindings()
	message.text = "Keyboard bindings reset. Controller options stay as selected."
	get_viewport().gui_release_focus()

func _input(event: InputEvent) -> void:
	if waiting >= 0 and event is InputEventKey:
		get_viewport().set_input_as_handled()
		if not event.pressed or event.echo:
			return
		if event.physical_keycode == KEY_ESCAPE:
			waiting = -1
			message.text = "Cancelled. Previous binding kept."
			return
		if event.ctrl_pressed or event.alt_pressed or event.meta_pressed or event.shift_pressed or event.physical_keycode in [0, KEY_SHIFT, KEY_ALT, KEY_CTRL, KEY_META, KEY_CAPSLOCK, KEY_NUMLOCK, KEY_SCROLLLOCK]:
			message.text = "Choose a key without modifiers. Escape cancels."
			return
		if event.physical_keycode == keys[1 - waiting]:
			message.text = "That key already controls the other direction. Choose another, or Escape."
			return
		keys[waiting] = event.physical_keycode
		waiting = -1
		apply_bindings()
		message.text = "Binding updated. Use the new key to move the dot. Bindings stay in memory."
		get_viewport().gui_release_focus()

func _process(delta: float) -> void:
	if message == null:
		return
	if waiting >= 0:
		seconds -= delta
		if seconds <= 0:
			waiting = -1
			message.text = "Capture timed out. Previous binding kept."
	else:
		position_x = clampf(position_x + Input.get_axis("free_left", "free_right") * minf(delta, 0.1) * 0.55, 0.03, 0.97)
	marker.position = Vector2(position_x * (arena.size.x - marker.size.x), 64)
	signal_label.text = "Action strength — left: %.2f   right: %.2f" % [Input.get_action_strength("free_left"), Input.get_action_strength("free_right")]
	controller_label.text = "No controller detected. This demo also works with a keyboard." if Input.get_connected_joypads().is_empty() else "Controller detected. Mappings follow Godot’s standard axis 0; hardware support varies."
